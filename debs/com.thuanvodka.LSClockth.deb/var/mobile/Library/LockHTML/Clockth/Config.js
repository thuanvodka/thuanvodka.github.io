
 //Scripts by JunesiPhone, mod by Jeeepers7

var twentyfour = false;
var padzero = false;
var refresh = 5000;

var language = "en"; // en, cz, it, sp, de, fr, zh 
