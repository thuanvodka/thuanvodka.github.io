
var Level = "";
var State = "";

$.ajaxSetup({
cache: false,
headers: {'Cache-Control': 'no-cache'}
});

function init() {

refreshLocationTimer = setTimeout(init, 10*1000);

jQuery.get('file:///private/var/mobile/Library/BatteryStats.txt', function(appdata) {

var myvar = appdata;
var substr = appdata.split('\n');
var Level=substr[0].split(':')[1];
var State=substr[1].split(':')[1];

if( Level > 0  && Level <= 2 )  document.getElementById("BatteryImage").src="Images/Battery/1.png";
if( Level > 2  && Level <= 5 )  document.getElementById("BatteryImage").src="Images/Battery/2.png";
if( Level > 5 && Level <= 10 )  document.getElementById("BatteryImage").src="Images/Battery/3.png";
if( Level > 10 && Level <= 20 ) document.getElementById("BatteryImage").src="Images/Battery/4.png";
if( Level > 20 && Level <= 25 ) document.getElementById("BatteryImage").src="Images/Battery/5.png";
if( Level > 25 && Level <= 35 ) document.getElementById("BatteryImage").src="Images/Battery/6.png";
if( Level > 35 && Level <= 45 ) document.getElementById("BatteryImage").src="Images/Battery/7.png";
if( Level > 45 && Level <= 50 ) document.getElementById("BatteryImage").src="Images/Battery/8.png";
if( Level > 50 && Level <= 55 ) document.getElementById("BatteryImage").src="Images/Battery/9.png";
if( Level > 55 && Level <= 65 ) document.getElementById("BatteryImage").src="Images/Battery/10.png";
if( Level > 65 && Level <= 70 ) document.getElementById("BatteryImage").src="Images/Battery/11.png";
if( Level > 70 && Level <= 80 ) document.getElementById("BatteryImage").src="Images/Battery/12.png";
if( Level > 80 && Level <= 85 ) document.getElementById("BatteryImage").src="Images/Battery/13.png";
if( Level > 85 && Level <= 90 ) document.getElementById("BatteryImage").src="Images/Battery/14.png";
if( Level > 90 && Level <= 95 ) document.getElementById("BatteryImage").src="Images/Battery/15.png";
if( Level > 95 && Level <= 98 ) document.getElementById("BatteryImage").src="Images/Battery/16.png";
if( Level > 98 && Level <= 100 ) document.getElementById("BatteryImage").src="Images/Battery/17.png";



document.getElementById("LevelDisplay").innerHTML = Level +"%";
document.getElementById("StateDisplay").innerHTML = State;

});

}