/*
Configurations
Credits: Original code by Junesiphone.
*/

var Line1Text = "Learn from yesterday"; 
var Line2Text = "Hope for tomorrow";
