/*
Configurations
Credits: Original code by Dacal & Junesiphone. Modified by Evelyn.
*/

var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh"
var lightMode = false;   // true for light mode, false for dark mode
var IconSet = "Plain";   // choose your weather icon pack here
var noOfApps = "68";   // enter the number of apps on your device


var ChangeClick = true;   // don't change. keep as true.
