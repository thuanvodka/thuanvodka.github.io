var height = "400"; //Height of the holder (in pixels)
var width = "300"; //Width of the holder (in pixels)
var borderradius = "25"; //Border radius of the holder (in pixels)
var color = "25, 25, 25"; //Color in RGB (use this tool: bit.ly/colorpicker)
var opacity = "0.7"; //Opacity (0.0 = transparent - 1.0 non-opaque)
var blur = false; //Toggle blur
var blurradius = "15"; //Blur amount (in pixels)
var header = false; //Toggle header
var headercolor = "#ffffff"; //Header color (in hex or color name)
var headertext = "Applications"; //Header text
var textcolor = "#101010"; //Color of header text (in hex or color name)