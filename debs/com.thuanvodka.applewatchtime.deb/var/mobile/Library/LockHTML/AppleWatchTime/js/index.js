var _createClass = function () {function defineProperties(target, props) {for (var i = 0; i < props.length; i++) {var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);}}return function (Constructor, protoProps, staticProps) {if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;};}();function _classCallCheck(instance, Constructor) {if (!(instance instanceof Constructor)) {throw new TypeError("Cannot call a class as a function");}}var Clock = function () {
  function Clock(id) {_classCallCheck(this, Clock);
    var el = document.getElementById(id);
    this.unitHr = el.querySelector('.clock__unit--hours');
    this.unitMin = el.querySelector('.clock__unit--minutes');
    this.unitSec = el.querySelector('.clock__unit--seconds');
    this.timeText = el.querySelector('.time');
    this.timeFormat = el.querySelector('.time-format');

    this.setTime();
    this.init();
  }_createClass(Clock, [{ key: 'buildTimeRings', value: function buildTimeRings(

    h, m, s) {
      var hours = h / 24 * 100;
      var minutes = m / 60 * 100;
      var seconds = s / 60 * 100;

      this.progress(this.unitHr, hours);
      this.progress(this.unitMin, minutes);
      this.progress(this.unitSec, seconds);
    } }, { key: 'checkTime', value: function checkTime(

    unit) {
      if (unit < 10) unit = '0' + unit;
      return unit;
    } }, { key: 'formatHours', value: function formatHours(

    hours) {
      if (this.timeFormat.checked) {
        hours = hours % 12;
        hours = hours ? hours : 12;
      }

      return hours;
    } }, { key: 'progress', value: function progress(

    unit, percent) {
      var radius = unit.r.baseVal.value;
      var circumference = radius * 2 * Math.PI;

      unit.style.strokeDasharray = circumference + ' ' + circumference;
      unit.style.strokeDashoffset = circumference - percent / 100 * circumference;

      if (percent < 1) {
        unit.style.transitionTimingFunction = 'cubic-bezier(0.85, 0, 0.05, 1)';
      } else {
        unit.style.transitionTimingFunction = 'linear';
      }
    } }, { key: 'setTime', value: function setTime()

    {
      var now = new Date();
      var hours = this.checkTime(now.getHours());
      var minutes = this.checkTime(now.getMinutes());
      var seconds = this.checkTime(now.getSeconds());

      this.buildTimeRings(hours, minutes, seconds);
      this.timeText.innerHTML = this.formatHours(hours) + ':' + minutes;
    } }, { key: 'init', value: function init()

    {
      setInterval(this.setTime.bind(this), 10);
    } }]);return Clock;}();


var clock = new Clock("clock");